## Our Backers and supporters

You can join them in supporting Phalcon and Zephir development by visiting our page on [Patreon](https://www.patreon.com/phalcon) and becoming a patron!

### Supporters

<a href="https://pdffiller.com/">
  <img width="240px" src="https://raw.githubusercontent.com/phalcon/cphalcon/master/backers/pdffiller-240x60.png">
</a>


### Gold Sponsor - ($500 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1205385)

No pledges yet.


### Silver Sponsor - ($250 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1204296)

<a href="https://mctekk.com/">
  <img width="240px" src="https://raw.githubusercontent.com/phalcon/cphalcon/master/backers/mctekk-240x60.png">
</a>

<a href="https://abits.com/">
  <img width="240px" src="https://raw.githubusercontent.com/phalcon/cphalcon/master/backers/abits-240x60.png">
</a>


### Bronze Sponsor ($100 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1204282)

No pledges yet.


### Gold Backer ($50 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1204241)

- David Schissler ([@dschissler](https://github.com/dschissler))
- Wojtek Ślawski ([@Jurigag](https://github.com/Jurigag))


### Silver Backer ($10 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1185010)

- Carlos Cardozo
- Robert Al-Romhein
- Łukasz Krawczyk
- Gary Rutland ([@garyrutland](https://github.com/garyrutland))
- Gustavo Miranda
- Ignacio Vazquez
- Jonny Paylor ([@jpaylor](https://github.com/jpaylor))
- Agapie Aurel
- Hristomir Kotzev ([@izopi4a](https://github.com/izopi4a))

### Bronze Backer ($5 or more)

[Pledge](https://www.patreon.com/bePatron?u=4653615&rid=1221352)

- Philipp Sundermeyer
- Mateusz B
- Valerio Belli
- Angel Vega
- Thien Tran ([@duythien](https://github.com/duythien))
- Magnus Holvid
- Semen Pinigin
- Daif Alotaibi ([@dalf](https://github.com/daif))
- Baruch Spinoza
